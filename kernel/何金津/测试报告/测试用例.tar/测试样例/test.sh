make
insmod no_hash_pointers_test.ko
rmmod no_hash_pointers_test.ko
echo "no_hash_pointers_test log"
dmesg | tail -n 12