#include <linux/init.h>
#include <linux/module.h>
#include <linux/slab.h>

extern bool no_hash_pointers;
static int __init no_hash_pointers_test_init(void)
{
		int array_stack[3] = {1, 1, 1};
		int *array_heap = (int*)kmalloc(3 * sizeof(int), GFP_KERNEL);

		printk(KERN_ALERT "no_hash_pointers_test module init\n");

		printk(KERN_ALERT "now no_hash_pointers = %d", no_hash_pointers);

		printk(KERN_ALERT "stack array with %%pt:%pt, %pt, %pt\n", &array_stack[0], &array_stack[1], &array_stack[2]);
		printk(KERN_ALERT "stack array with %%p:%p, %p, %p\n", &array_stack[0], &array_stack[1], &array_stack[2]);
		printk(KERN_ALERT "stack array with %%pk:%pk, %pk, %pk\n", &array_stack[0], &array_stack[1], &array_stack[2]);
		printk(KERN_ALERT "stack array with %%px:%px, %px, %px\n\n", &array_stack[0], &array_stack[1], &array_stack[2]);
		
		printk(KERN_ALERT "heap array with %%pt:%pt, %pt, %pt\n", &array_heap[0], &array_heap[1], &array_heap[2]);
		printk(KERN_ALERT "heap array with %%p:%p, %p, %p\n", &array_heap[0], &array_heap[1], &array_heap[2]);
		printk(KERN_ALERT "heap array with %%pk:%pk, %pk, %pk\n", &array_heap[0], &array_heap[1], &array_heap[2]);
		printk(KERN_ALERT "heap array with %%px:%px, %px, %px\n", &array_heap[0], &array_heap[1], &array_heap[2]);
		
		kfree(array_heap);
		return 0;
}

static void __exit no_hash_pointers_test_exit(void)
{
        printk(KERN_ALERT "no_hash_pointers_test module exit\n");
}

module_init(no_hash_pointers_test_init);
module_exit(no_hash_pointers_test_exit);

MODULE_LICENSE("GPL v2");
MODULE_AUTHOR("He Jinjin <jinjin@isrc.iscas.ac.cn>");
MODULE_DESCRIPTION("no_hash_pointers_test module");
MODULE_ALIAS("no_hash_pointers_test module");
MODULE_VERSION("V1.0");
